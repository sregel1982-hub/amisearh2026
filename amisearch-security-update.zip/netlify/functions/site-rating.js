import { createHash } from "node:crypto";
import {
  getSupabaseAdmin,
  json,
  readJson,
  rateLimit,
  rateLimitedResponse,
  requireUser,
} from "./security-helper.mjs";

function hashIdentity(value) {
  return createHash("sha256").update(String(value)).digest("hex");
}

async function getSummary(supabase) {
  const { data, error } = await supabase.from("site_ratings").select("rating").limit(10_000);
  if (error) throw error;
  const ratings = (data || []).map((row) => Number(row.rating)).filter((value) => value >= 1 && value <= 5);
  return {
    average: ratings.length ? Number((ratings.reduce((sum, value) => sum + value, 0) / ratings.length).toFixed(2)) : 0,
    total: ratings.length,
  };
}

export default async function handler(req) {
  let supabase;
  try {
    supabase = getSupabaseAdmin();
  } catch (error) {
    console.error("[site-rating] DB init failed:", error?.message || error);
    return json({ error: "Az értékelés szolgáltatás nincs konfigurálva." }, 500);
  }

  try {
    if (req.method === "GET") return json(await getSummary(supabase));
    if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

    const user = await requireUser(req);
    if (!user) return json({ error: "Bejelentkezés szükséges.", code: "unauthorized" }, 401);
    const rate = rateLimit(`site-rating:${user.id}`, 5, 60 * 60_000);
    if (!rate.allowed) return rateLimitedResponse(rate);

    const body = await readJson(req, 10_000);
    const rating = Number(body.rating);
    if (!Number.isInteger(rating) || rating < 1 || rating > 5) {
      return json({ error: "Az értékelésnek 1 és 5 közötti egész számnak kell lennie." }, 400);
    }

    const forwarded = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
    const ipHash = hashIdentity(`${user.id}:${forwarded}`);
    const { data: existing, error: lookupError } = await supabase
      .from("site_ratings")
      .select("id")
      .eq("ip_hash", ipHash)
      .maybeSingle();
    if (lookupError) throw lookupError;

    if (existing) {
      const { error } = await supabase.from("site_ratings").update({ rating }).eq("id", existing.id);
      if (error) throw error;
    } else {
      const { error } = await supabase.from("site_ratings").insert({ rating, ip_hash: ipHash });
      if (error) throw error;
    }
    return json(await getSummary(supabase));
  } catch (error) {
    console.error("[site-rating] request failed:", error?.message || error);
    return json({ error: "Az értékelés mentése nem sikerült." }, 500);
  }
}

export const config = {};
