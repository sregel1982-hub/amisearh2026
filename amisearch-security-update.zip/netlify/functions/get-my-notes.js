import {
  getSupabaseAdmin,
  json,
  rateLimit,
  rateLimitedResponse,
  requireUser,
} from "./security-helper.mjs";

export default async function handler(req) {
  if (req.method !== "GET") return json({ error: "Method not allowed" }, 405);

  const user = await requireUser(req);
  if (!user) return json({ error: "Bejelentkezés szükséges.", code: "unauthorized" }, 401);

  const rate = rateLimit(`get-my-notes:${user.id}`, 60, 60_000);
  if (!rate.allowed) return rateLimitedResponse(rate);

  try {
    const supabase = getSupabaseAdmin();
    const { data: notes, error } = await supabase
      .from("uploaded_notes")
      .select("id, title, subject, language, created_at, file_name")
      .eq("uploader_identity_id", user.id)
      .order("created_at", { ascending: false })
      .limit(100);

    if (error) {
      console.error("[get-my-notes] query failed:", error.message);
      return json({ error: "A jegyzetek betöltése nem sikerült." }, 500);
    }
    return json({ success: true, notes: notes || [] });
  } catch (error) {
    console.error("[get-my-notes] failed:", error?.message || error);
    return json({ error: "A jegyzetek betöltése nem sikerült." }, 500);
  }
}

export const config = {};
