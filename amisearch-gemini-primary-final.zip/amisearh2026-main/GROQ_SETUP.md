# AMISEARCH – Gemini elsődleges, Groq tartalék AI

Az AMISEARCH fő AI-szolgáltatója ismét a **Gemini**. A Groq csak tartalék szolgáltató: akkor lép életbe, ha a Gemini-kulcs hiányzik vagy a Gemini-kérés hibát ad.

## Netlify környezeti változók

A Netlify projektben nyisd meg a **Site configuration → Environment variables** részt, majd add hozzá vagy ellenőrizd:

| Változó | Kötelező | Érték |
|---|---:|---|
| `GEMINI_API_KEY` | Igen | A Google AI Studio / Gemini API kulcsa |
| `GEMINI_MODEL` | Nem | Alapértelmezés: `gemini-2.5-flash` |
| `GROQ_API_KEY` | Nem | Tartalékkulcs a Groq Console-ból |
| `GROQ_MODEL` | Nem | Alapértelmezés: `llama-3.3-70b-versatile` |

A kulcsokat ne írd a forráskódba, és ne commitold `.env` fájlba. A változók mentése után indíts új Netlify-deployt, mert a Functionök deploykor kapják meg a környezeti változókat.

A meglévő Supabase változók (`SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`) továbbra is szükségesek a belépéshez, kvótához és jegyzetkontekstushoz.

## Mi történik hiba esetén?

A `netlify/functions/ai-client.mjs` először Geminit próbálja használni. Ha a Gemini-kérés hibázik, és a `GROQ_API_KEY` meg van adva, a kérés automatikusan Groqra kerül. Így a fizetett Gemini-kulcs marad az elsődleges, de egy átmeneti szolgáltatói hiba nem állítja le az oldalt.

## Vizuális és PDF-javítások

Az AI képkérésének válasza valódi Markdown-képet, címet és külön kattintható forráshivatkozást ad. A frontend ezt képként és linkként rendereli. A vizsgafeladat PDF-nyomtatása A4-es oldalbeállítást, kék címsorokat, fekete törzsszöveget, képméretezést és oldaltörési szabályokat használ.

## Hangos felolvasás

Az AI-válaszok alatt megjelenik a **Felolvasás** gomb. Ez a böngésző beépített `speechSynthesis` funkcióját használja, ezért külön hangszolgáltatói kulcs nem kell hozzá. Magyar válasznál `hu-HU`, angol válasznál `en-US` nyelvi beállítást használ. A funkció a felhasználó böngészőjének támogatásától és telepített hangjaitól függ.

## Ellenőrzés deploy után

1. Jelentkezz be az AMISEARCH oldalra.
2. Tegyél fel magyar AI Tutor-kérdést, és ellenőrizd, hogy a válasz Geminiből érkezik.
3. Kérj képet; ellenőrizd, hogy a kép, a cím és a kattintható forrás is megjelenik.
4. Generálj vizsgafeladatsort, majd használd a PDF gombot. A nyomtatási előnézetben válaszd a **Mentés PDF-ként** lehetőséget.
5. Próbáld ki a **Felolvasás** gombot.
