import { GoogleGenAI } from "@google/genai";
import {
  getEnv,
  groqConfigured,
  groqChat,
  groqText,
  groqStreamToTextStream
} from "./groq-client.mjs";

const geminiKey = () => getEnv("GEMINI_API_KEY");
const geminiModel = () => getEnv("GEMINI_MODEL") || "gemini-2.5-flash";

export function aiConfigured() {
  return Boolean(geminiKey() || groqConfigured());
}

export function providerStatus() {
  return { gemini: Boolean(geminiKey()), groq: groqConfigured() };
}

function geminiClient() {
  const key = geminiKey();
  return key ? new GoogleGenAI({ apiKey: key }) : null;
}

function geminiContents(userMessage) {
  return [{ role: "user", parts: [{ text: String(userMessage || "") }] }];
}

export async function completeAi({ system, user, temperature = 0.2, maxTokens = 2048 }) {
  let lastError;
  const client = geminiClient();
  if (client) {
    try {
      const result = await client.models.generateContent({
        model: geminiModel(),
        systemInstruction: system,
        contents: geminiContents(user),
        generationConfig: { temperature, maxOutputTokens: maxTokens }
      });
      return { text: result?.text || "", provider: "gemini" };
    } catch (error) {
      lastError = error;
      console.warn("Gemini failed; trying Groq fallback:", error?.message || error);
    }
  }

  if (groqConfigured()) {
    try {
      const response = await groqChat([
        { role: "system", content: system },
        { role: "user", content: user }
      ], { temperature, maxTokens });
      return { text: groqText(await response.json()), provider: "groq" };
    } catch (error) {
      lastError = error;
    }
  }

  throw lastError || new Error("No AI provider is configured");
}

function geminiStreamToTextStream(stream) {
  const encoder = new TextEncoder();
  return new ReadableStream({
    async start(controller) {
      try {
        for await (const chunk of stream) {
          const text = chunk?.text || "";
          if (text) controller.enqueue(encoder.encode(String(text).normalize("NFC")));
        }
        controller.close();
      } catch (error) {
        controller.error(error);
      }
    }
  });
}

export async function streamAi({ system, user, temperature = 0.2, maxTokens = 2048 }) {
  let lastError;
  const client = geminiClient();
  if (client) {
    try {
      const stream = await client.models.generateContentStream({
        model: geminiModel(),
        systemInstruction: system,
        contents: geminiContents(user),
        generationConfig: { temperature, maxOutputTokens: maxTokens }
      });
      return { stream: geminiStreamToTextStream(stream), provider: "gemini" };
    } catch (error) {
      lastError = error;
      console.warn("Gemini stream failed; trying Groq fallback:", error?.message || error);
    }
  }

  if (groqConfigured()) {
    try {
      const response = await groqChat([
        { role: "system", content: system },
        { role: "user", content: user }
      ], { temperature, maxTokens, stream: true });
      return { stream: groqStreamToTextStream(response), provider: "groq" };
    } catch (error) {
      lastError = error;
    }
  }

  throw lastError || new Error("No AI provider is configured");
}

export function textStreamResponse(stream) {
  return new Response(stream, {
    status: 200,
    headers: {
      "Content-Type": "text/plain; charset=utf-8",
      "Cache-Control": "no-cache",
      "Access-Control-Allow-Origin": "*",
      "X-Content-Type-Options": "nosniff"
    }
  });
}
