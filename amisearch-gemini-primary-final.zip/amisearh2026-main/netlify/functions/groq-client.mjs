const getEnv = (key) =>
  (typeof Netlify !== "undefined" && Netlify.env?.get?.(key)) || process.env[key];

export function groqConfigured() {
  return Boolean(getEnv("GROQ_API_KEY"));
}

export function groqModel() {
  return getEnv("GROQ_MODEL") || "llama-3.3-70b-versatile";
}

export async function groqChat(messages, options = {}) {
  const apiKey = getEnv("GROQ_API_KEY");
  if (!apiKey) throw new Error("GROQ_API_KEY is not configured");

  const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: options.model || groqModel(),
      messages,
      temperature: options.temperature ?? 0.2,
      max_tokens: options.maxTokens ?? 2048,
      stream: Boolean(options.stream)
    })
  });

  if (!response.ok) {
    const detail = await response.text().catch(() => "");
    throw new Error(`Groq API ${response.status}: ${detail.slice(0, 500)}`);
  }
  return response;
}

export function groqText(data) {
  return data?.choices?.[0]?.message?.content || "";
}

export function groqStreamToTextStream(response) {
  const reader = response.body?.getReader();
  const decoder = new TextDecoder();
  const encoder = new TextEncoder();
  let buffer = "";

  return new ReadableStream({
    async start(controller) {
      if (!reader) {
        controller.close();
        return;
      }
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          const events = buffer.split("\n");
          buffer = events.pop() || "";
          for (const line of events) {
            if (!line.startsWith("data:")) continue;
            const payload = line.slice(5).trim();
            if (!payload || payload === "[DONE]") continue;
            try {
              const token = groqText({ choices: [{ message: { content: JSON.parse(payload)?.choices?.[0]?.delta?.content || "" } }] });
              if (token) controller.enqueue(encoder.encode(token.normalize("NFC")));
            } catch {
              // Ignore malformed SSE fragments; the next complete event is still usable.
            }
          }
        }
        buffer += decoder.decode();
        if (buffer.startsWith("data:")) {
          const payload = buffer.slice(5).trim();
          if (payload && payload !== "[DONE]") {
            try {
              const token = JSON.parse(payload)?.choices?.[0]?.delta?.content || "";
              if (token) controller.enqueue(encoder.encode(token.normalize("NFC")));
            } catch {}
          }
        }
        controller.close();
      } catch (error) {
        controller.error(error);
      }
    }
  });
}

export function plainTextResponse(stream) {
  return new Response(stream, {
    status: 200,
    headers: {
      "Content-Type": "text/plain; charset=utf-8",
      "Cache-Control": "no-cache",
      "Access-Control-Allow-Origin": "*",
      "X-Content-Type-Options": "nosniff"
    }
  });
}

export function groqErrorMessage(error) {
  return error?.message || "Groq AI service unavailable";
}

export { getEnv };
